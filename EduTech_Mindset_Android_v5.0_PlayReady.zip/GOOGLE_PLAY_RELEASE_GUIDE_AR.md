# دليل نشر EduTech Mindset v5.0 على Google Play

1. **رفع المشروع على GitHub:** ارفع محتويات هذا المجلد إلى مستودعك، وسيقوم مسار `.github/workflows/build-release.yml` تلقائياً بتشغيل الاختبارات وبناء ملف `.aab` (الخاص بمتجر Google Play) وملف `.apk` (للاختبار المباشر).
2. **توقيع الحزمة (Upload Keystore):** أنشئ مفتاح توقيع `.jks` في Android Studio عبر `Build > Generate Signed Bundle / APK` واحفظه في مكان آمن.
3. **بطاقة المتجر (Store Listing):**
   - الفئة: **Education (تطبيق تعليمي عام للمعلمين والطلاب)**.
   - رابط سياسة الخصوصية: `https://edutech-mindset.pages.dev/privacy.html`.
   - أمان البيانات (Data Safety): لا يجمع التطبيق بيانات تتبع إعلانية؛ بيانات عقلية النمو والحزم تُحفظ محلياً في جهاز المستخدم.
   - أذونات المشاركة المحلية (`NEARBY_WIFI_DEVICES` و`BLUETOOTH_SCAN`) مدمجة مع علامة `neverForLocation` لضمان عدم رفض المراجعة.
