package dev.pages.edutechmindset

import dev.pages.edutechmindset.data.edupack.EduPackParser
import dev.pages.edutechmindset.data.edupack.EduPackWriter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream

class EduPackAndMindsetTest {
    @Test
    fun demoPackRoundTripZipIsConsistent() {
        val demo = EduPackParser.builtInDemoEntity()
        val bytes = EduPackWriter.toZipBytes(demo)
        assertTrue(bytes.isNotEmpty())
        val parsedBack = EduPackParser.parseFromZipStream(ByteArrayInputStream(bytes))
        assertEquals(demo.packId, parsedBack.packId)
        assertEquals(demo.title, parsedBack.title)
    }
}
