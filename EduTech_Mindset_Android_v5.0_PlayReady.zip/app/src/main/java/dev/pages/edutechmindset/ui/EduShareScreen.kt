package dev.pages.edutechmindset.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dev.pages.edutechmindset.data.local.EduPackEntity
import dev.pages.edutechmindset.data.share.EduShareManager

@Composable
fun EduShareScreen(
    packs: List<EduPackEntity>,
    shareManager: EduShareManager
) {
    val status by shareManager.status.collectAsState()
    val endpoints by shareManager.discoveredEndpoints.collectAsState()
    var selectedPack by remember(packs) { mutableStateOf(packs.firstOrNull()) }
    var permissionsGranted by remember { mutableStateOf(false) }

    val requiredPermissions = remember {
        buildList {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.NEARBY_WIFI_DEVICES)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                add(Manifest.permission.BLUETOOTH_ADVERTISE)
                add(Manifest.permission.BLUETOOTH_CONNECT)
                add(Manifest.permission.BLUETOOTH_SCAN)
            } else {
                add(Manifest.permission.ACCESS_FINE_LOCATION)
            }
        }.toTypedArray()
    }

    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        permissionsGranted = result.values.all { it }
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("📡 المشاركة المحلية (EduShare)", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("انقل حزم .edupack بين الهواتف في الصف أو المنزل بدون إنترنت نهائياً.", style = MaterialTheme.typography.bodySmall)

        Card(modifier = Modifier.fillMaxWidth()) {
            Text("الحالة: $status", modifier = Modifier.padding(14.dp), fontWeight = FontWeight.SemiBold)
        }

        if (!permissionsGranted) {
            Button(
                onClick = { permLauncher.launch(requiredPermissions) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("🔐 منح أذونات الاتصال القريب (Bluetooth / Wi-Fi)")
            }
        }

        selectedPack?.let { pack ->
            Button(
                onClick = { shareManager.startBroadcasting("EduTech Sender", pack) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("📤 بث حزمة: ${pack.title}")
            }
        }

        OutlinedButton(
            onClick = { shareManager.startDiscovering("EduTech Student") },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("📥 البحث عن حزم متاحة للاستلام")
        }

        if (endpoints.isNotEmpty()) {
            Text("الأجهزة المكتشفة:", fontWeight = FontWeight.Bold)
            endpoints.forEach { (id, name) ->
                Card(onClick = { shareManager.connectToEndpoint("EduTech Student", id) }, modifier = Modifier.fillMaxWidth()) {
                    Text("📲 الاتصال بـ $name واستلام الحزمة", modifier = Modifier.padding(14.dp))
                }
            }
        }

        TextButton(onClick = { shareManager.stopAll() }, modifier = Modifier.fillMaxWidth()) {
            Text("⏹️ إيقاف البث والبحث")
        }
    }
}
