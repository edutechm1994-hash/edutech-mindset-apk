package dev.pages.edutechmindset.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dev.pages.edutechmindset.data.local.EduPackEntity

@Composable
fun EduPackLibraryScreen(
    packs: List<EduPackEntity>,
    onImportClick: () -> Unit,
    onOpenPack: (EduPackEntity) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("📦 مكتبة حزم .edupack", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Button(onClick = onImportClick, modifier = Modifier.fillMaxWidth()) {
            Text("📂 استيراد حزمة .edupack من الهاتف")
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(packs, key = { it.packId }) { pack ->
                Card(onClick = { onOpenPack(pack) }, modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(pack.title, fontWeight = FontWeight.Bold)
                        Text("${pack.subject} • ${pack.grade}", style = MaterialTheme.typography.bodySmall)
                        Text("المصدر: ${pack.author}", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}
