package dev.pages.edutechmindset.data

import dev.pages.edutechmindset.data.edupack.EduPackParser
import dev.pages.edutechmindset.data.local.DailyCheckInEntity
import dev.pages.edutechmindset.data.local.EduTechDao
import dev.pages.edutechmindset.data.local.MindsetStateEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class MindsetRepository(private val dao: EduTechDao) {

    fun todayString(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    suspend fun ensureInitialized() {
        if (dao.getMindsetState() == null) {
            dao.saveMindsetState(MindsetStateEntity())
        }
        dao.savePack(EduPackParser.builtInDemoEntity())
    }

    suspend fun setRole(role: String) {
        val cur = dao.getMindsetState() ?: MindsetStateEntity()
        dao.saveMindsetState(cur.copy(role = if (role == "teacher") "teacher" else "student"))
    }

    suspend fun recordDailyCheckIn(note: String): Pair<MindsetStateEntity, Boolean> {
        val cur = dao.getMindsetState() ?: MindsetStateEntity()
        val today = todayString()
        var shieldUsed = false
        var newStreak = cur.streak
        var newShields = cur.freezeShields
        var newTotal = cur.totalCheckIns

        if (cur.lastCheckInDate != today) {
            if (cur.lastCheckInDate.isNotBlank()) {
                val diff = daysBetween(cur.lastCheckInDate, today)
                when {
                    diff == 1L -> newStreak += 1
                    diff in 2L..3L && newShields > 0 -> {
                        newShields -= 1
                        newStreak += 1
                        shieldUsed = true
                    }
                    else -> newStreak = 1
                }
            } else {
                newStreak = 1
            }
            newTotal += 1
        }

        val badges = cur.badgesCsv.split(",").filter { it.isNotBlank() }.toMutableSet()
        if (newTotal >= 1) badges.add("مُبادر")
        if (newStreak >= 3) badges.add("مثابر")
        if (newTotal >= 7) badges.add("صانع أمل")

        val updated = cur.copy(
            streak = newStreak,
            freezeShields = newShields,
            lastCheckInDate = today,
            totalCheckIns = newTotal,
            badgesCsv = badges.joinToString(",")
        )
        dao.saveMindsetState(updated)
        if (note.isNotBlank()) {
            dao.insertCheckIn(DailyCheckInEntity(date = today, role = cur.role, note = note.trim()))
        }
        return updated to shieldUsed
    }

    private fun daysBetween(older: String, newer: String): Long {
        return try {
            val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val d1 = fmt.parse(older) ?: return 99
            val d2 = fmt.parse(newer) ?: return 99
            TimeUnit.MILLISECONDS.toDays(d2.time - d1.time)
        } catch (_: Exception) {
            99
        }
    }
}
