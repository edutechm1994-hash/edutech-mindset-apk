package dev.pages.edutechmindset.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val WalnutWood = Color(0xFF4A3528)
val BrushedBrass = Color(0xFFC6A468)
val WarmOak = Color(0xFFB88B5E)
val WarmLedGlow = Color(0xFFF6E3B8)
val WarmOffWhite = Color(0xFFFBF9F4)
val DeepSlate = Color(0xFF0F172A)

private val LightColors = lightColorScheme(
    primary = WalnutWood,
    onPrimary = WarmLedGlow,
    secondary = BrushedBrass,
    onSecondary = WalnutWood,
    tertiary = WarmOak,
    background = WarmOffWhite,
    surface = Color.White,
    onBackground = Color(0xFF1E293B),
    onSurface = Color(0xFF1E293B)
)

private val DarkColors = darkColorScheme(
    primary = BrushedBrass,
    onPrimary = WalnutWood,
    secondary = WarmOak,
    onSecondary = Color.White,
    background = DeepSlate,
    surface = Color(0xFF1E293B),
    onBackground = Color(0xFFF8FAFC),
    onSurface = Color(0xFFF8FAFC)
)

@Composable
fun EduTechTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content
    )
}
