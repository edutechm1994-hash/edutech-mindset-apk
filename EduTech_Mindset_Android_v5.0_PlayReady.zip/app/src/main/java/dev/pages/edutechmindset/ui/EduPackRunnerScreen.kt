package dev.pages.edutechmindset.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dev.pages.edutechmindset.data.edupack.ParsedEduPack

@Composable
fun EduPackRunnerScreen(
    pack: ParsedEduPack,
    isTeacher: Boolean,
    onBack: () -> Unit
) {
    var tab by remember { mutableIntStateOf(if (isTeacher) 3 else 0) }
    val hintCounts = remember { mutableStateMapOf<String, Int>() }
    val flippedCards = remember { mutableStateMapOf<Int, Boolean>() }
    val selectedAnswers = remember { mutableStateMapOf<String, Int>() }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(pack.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = onBack) { Text("رجوع") }
        }

        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("الدرس") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("سقراطي") })
            Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("مراجعة") })
            Tab(selected = tab == 3, onClick = { tab = 3 }, text = { Text("المعلم") })
        }

        Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            when (tab) {
                0 -> {
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Text("📌 ${pack.summary}", modifier = Modifier.padding(14.dp), fontWeight = FontWeight.SemiBold)
                    }
                    pack.microCards.forEach { card ->
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(card.title, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(4.dp))
                                Text(card.body)
                            }
                        }
                    }
                }
                1 -> {
                    pack.questions.forEach { q ->
                        val shownHints = hintCounts[q.id] ?: 0
                        val picked = selectedAnswers[q.id]
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(q.prompt, fontWeight = FontWeight.Bold)
                                q.options.forEachIndexed { idx, opt ->
                                    val label = if (picked == idx) {
                                        if (idx == q.correctIndex) "✅ $opt" else "❌ $opt"
                                    } else opt
                                    OutlinedButton(onClick = { selectedAnswers[q.id] = idx }, modifier = Modifier.fillMaxWidth()) {
                                        Text(label)
                                    }
                                }
                                Button(onClick = { hintCounts[q.id] = shownHints + 1 }) {
                                    Text("🧭 تلميح سقراطي")
                                }
                                q.hints.take(shownHints).forEach { h ->
                                    Text("💡 $h", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
                2 -> {
                    pack.flashcards.forEachIndexed { idx, fc ->
                        val flipped = flippedCards[idx] == true
                        Card(onClick = { flippedCards[idx] = !flipped }, modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("🃏 ${fc.front}", fontWeight = FontWeight.Bold)
                                if (flipped) {
                                    Spacer(Modifier.height(6.dp))
                                    Text("✅ ${fc.back}")
                                } else {
                                    Text("(اضغط لقلب البطاقة)", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
                3 -> {
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("🎯 أهداف الدرس", fontWeight = FontWeight.Bold)
                            pack.objectives.forEach { Text("• $it") }
                        }
                    }
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("⏱️ توزيع الحصة", fontWeight = FontWeight.Bold)
                            pack.timeline.forEach { Text("• $it") }
                        }
                    }
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("🏫 النشاط الصفي", fontWeight = FontWeight.Bold)
                            Text(pack.classroomActivity)
                        }
                    }
                }
            }
        }
    }
}
