package dev.pages.edutechmindset.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dev.pages.edutechmindset.data.local.DailyCheckInEntity
import dev.pages.edutechmindset.data.local.MindsetStateEntity
import dev.pages.edutechmindset.ui.theme.WarmOak

@Composable
fun MindsetHomeScreen(
    state: MindsetStateEntity,
    todayDate: String,
    recentNotes: List<DailyCheckInEntity>,
    onRoleChange: (String) -> Unit,
    onCheckIn: (String) -> Unit
) {
    var noteText by remember { mutableStateOf("") }
    val checkedToday = state.lastCheckInDate == todayDate
    val isTeacher = state.role == "teacher"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("عقلية التعليم والتكنولوجيا", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
        Text("التكنولوجيا هي مجرد أداة.. إن العقلية هي التي تهم حقاً", style = MaterialTheme.typography.bodySmall, color = WarmOak)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = !isTeacher,
                onClick = { onRoleChange("student") },
                label = { Text("🎓 مسار الطالب") }
            )
            FilterChip(
                selected = isTeacher,
                onClick = { onRoleChange("teacher") },
                label = { Text("🧑‍🏫 استوديو المعلم") }
            )
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("🔥 سلسلة الصمود: ${state.streak} يوم  |  🛡️ دروع الحماية: ${state.freezeShields}", fontWeight = FontWeight.Bold)
                val badges = state.badgesCsv.split(",").filter { it.isNotBlank() }
                Text(
                    if (badges.isEmpty()) "الأوسمة: 🌱 ابدأ أول خطوة اليوم"
                    else "الأوسمة: " + badges.joinToString(" • ") { "🏅 $it" },
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("🧠 مختبر عقلية النمو اليومي (60 ثانية)", fontWeight = FontWeight.Bold)
                Text(
                    if (isTeacher) "ما الفكرة التي ستبسّطها لطلابك اليوم بأسلوب عملي أو قصصي؟"
                    else "ما المفهوم الصعب الذي ستحوّله اليوم إلى نقطة قوة؟",
                    style = MaterialTheme.typography.bodyMedium
                )
                OutlinedTextField(
                    value = noteText,
                    onValueChange = { noteText = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("اكتب هدفك أو فكرتك اليوم...") },
                    singleLine = true
                )
                Button(
                    onClick = {
                        onCheckIn(noteText)
                        noteText = ""
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (checkedToday) "✅ تم تسجيل اليوم (تحديث الهدف)" else "🚀 تثبيت نية اليوم")
                }
            }
        }

        if (recentNotes.isNotEmpty()) {
            Text("أهدافك الأخيرة", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            recentNotes.take(3).forEach { item ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(item.date, style = MaterialTheme.typography.labelSmall, color = WarmOak)
                        Text(item.note, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}
