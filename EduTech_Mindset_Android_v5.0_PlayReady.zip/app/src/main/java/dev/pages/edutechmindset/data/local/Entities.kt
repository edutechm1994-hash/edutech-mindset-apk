package dev.pages.edutechmindset.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "mindset_state")
data class MindsetStateEntity(
    @PrimaryKey val id: Int = 1,
    val role: String = "student", // "student" or "teacher"
    val streak: Int = 0,
    val freezeShields: Int = 2,
    val lastCheckInDate: String = "",
    val totalCheckIns: Int = 0,
    val badgesCsv: String = ""
)

@Entity(tableName = "daily_checkins")
data class DailyCheckInEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String,
    val role: String,
    val note: String
)

@Entity(tableName = "edupacks")
data class EduPackEntity(
    @PrimaryKey val packId: String,
    val title: String,
    val subject: String,
    val grade: String,
    val author: String,
    val createdAt: String,
    val checksum: String,
    val studentContentJson: String,
    val socraticBankJson: String,
    val teacherStudioJson: String
)
