package dev.pages.edutechmindset

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import dev.pages.edutechmindset.data.MindsetRepository
import dev.pages.edutechmindset.data.edupack.EduPackParser
import dev.pages.edutechmindset.data.local.EduPackEntity
import dev.pages.edutechmindset.data.local.EduTechDatabase
import dev.pages.edutechmindset.data.local.MindsetStateEntity
import dev.pages.edutechmindset.ui.EduPackLibraryScreen
import dev.pages.edutechmindset.data.share.EduShareManager
import dev.pages.edutechmindset.ui.EduPackRunnerScreen
import dev.pages.edutechmindset.ui.EduShareScreen
import dev.pages.edutechmindset.ui.MindsetHomeScreen
import dev.pages.edutechmindset.ui.theme.EduTechTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = EduTechDatabase.getInstance(this)
        val repo = MindsetRepository(db.dao())

        setContent {
            EduTechTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    val scope = rememberCoroutineScope()
                    val snackbar = remember { SnackbarHostState() }
                    val state by db.dao().observeMindsetState().collectAsState(initial = MindsetStateEntity())
                    val recentNotes by db.dao().observeRecentCheckIns().collectAsState(initial = emptyList())
                    val packs by db.dao().observeAllPacks().collectAsState(initial = emptyList())
                    var selectedTab by remember { mutableIntStateOf(0) }
                    var activePack by remember { mutableStateOf<EduPackEntity?>(null) }
                    val shareManager = remember {
                        EduShareManager(this@MainActivity) { received ->
                            scope.launch {
                                db.dao().savePack(received)
                                snackbar.showSnackbar("📥 تم حفظ الحزمة المستلمة: ${received.title}")
                            }
                        }
                    }
                    DisposableEffect(Unit) { onDispose { shareManager.stopAll() } }

                    LaunchedEffect(Unit) {
                        repo.ensureInitialized()
                    }

                    val openPackLauncher = rememberLauncherForActivityResult(
                        ActivityResultContracts.OpenDocument()
                    ) { uri ->
                        if (uri != null) {
                            scope.launch {
                                try {
                                    val entity = withContext(Dispatchers.IO) {
                                        contentResolver.openInputStream(uri)?.use {
                                            EduPackParser.parseFromZipStream(it)
                                        } ?: error("تعذر قراءة الملف")
                                    }
                                    db.dao().savePack(entity)
                                    activePack = entity
                                    snackbar.showSnackbar("📦 تم استيراد الحزمة بنجاح")
                                } catch (e: Exception) {
                                    snackbar.showSnackbar("❌ ${e.message ?: "ملف غير صالح"}")
                                }
                            }
                        }
                    }

                    val currentState = state ?: MindsetStateEntity()

                    Scaffold(
                        snackbarHost = { SnackbarHost(snackbar) },
                        bottomBar = {
                            if (activePack == null) {
                                NavigationBar {
                                    NavigationBarItem(
                                        selected = selectedTab == 0,
                                        onClick = { selectedTab = 0 },
                                        icon = { Icon(Icons.Default.Psychology, contentDescription = null) },
                                        label = { Text("عقلية النمو") }
                                    )
                                    NavigationBarItem(
                                        selected = selectedTab == 1,
                                        onClick = { selectedTab = 1 },
                                        icon = { Icon(Icons.Default.Book, contentDescription = null) },
                                        label = { Text("الحزم") }
                                    )
                                    NavigationBarItem(
                                        selected = selectedTab == 2,
                                        onClick = { selectedTab = 2 },
                                        icon = { Icon(Icons.Default.Share, contentDescription = null) },
                                        label = { Text("المشاركة") }
                                    )
                                }
                            }
                        }
                    ) { padding ->
                        Box(modifier = Modifier.padding(padding)) {
                            val opened = activePack
                            if (opened != null) {
                                EduPackRunnerScreen(
                                    pack = EduPackParser.toParsedModel(opened),
                                    isTeacher = currentState.role == "teacher",
                                    onBack = { activePack = null }
                                )
                            } else {
                                when (selectedTab) {
                                    0 -> MindsetHomeScreen(
                                        state = currentState,
                                        todayDate = repo.todayString(),
                                        recentNotes = recentNotes,
                                        onRoleChange = { role -> scope.launch { repo.setRole(role) } },
                                        onCheckIn = { note ->
                                            scope.launch {
                                                val (_, shieldUsed) = repo.recordDailyCheckIn(note)
                                                snackbar.showSnackbar(
                                                    if (shieldUsed) "🛡️ تم تفعيل درع الصمود التلقائي واستمرت سلسلتك!"
                                                    else "🔥 تم تثبيت إنجازك اليومي بنجاح"
                                                )
                                            }
                                        }
                                    )
                                    1 -> EduPackLibraryScreen(
                                        packs = packs,
                                        onImportClick = { openPackLauncher.launch(arrayOf("*/*")) },
                                        onOpenPack = { activePack = it }
                                    )
                                    2 -> EduShareScreen(packs = packs, shareManager = shareManager)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
