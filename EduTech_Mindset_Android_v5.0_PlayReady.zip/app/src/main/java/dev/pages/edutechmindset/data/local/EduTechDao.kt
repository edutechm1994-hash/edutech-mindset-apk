package dev.pages.edutechmindset.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface EduTechDao {
    @Query("SELECT * FROM mindset_state WHERE id = 1")
    fun observeMindsetState(): Flow<MindsetStateEntity?>

    @Query("SELECT * FROM mindset_state WHERE id = 1")
    suspend fun getMindsetState(): MindsetStateEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveMindsetState(state: MindsetStateEntity)

    @Insert
    suspend fun insertCheckIn(entry: DailyCheckInEntity)

    @Query("SELECT * FROM daily_checkins ORDER BY id DESC LIMIT 14")
    fun observeRecentCheckIns(): Flow<List<DailyCheckInEntity>>

    @Query("SELECT * FROM edupacks ORDER BY createdAt DESC")
    fun observeAllPacks(): Flow<List<EduPackEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun savePack(pack: EduPackEntity)
}
