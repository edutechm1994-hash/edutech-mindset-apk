package dev.pages.edutechmindset.data.edupack

import dev.pages.edutechmindset.data.local.EduPackEntity
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object EduPackWriter {
    fun toZipBytes(entity: EduPackEntity): ByteArray {
        val manifest = JSONObject().apply {
            put("pack_id", entity.packId)
            put("schema_version", "1.0")
            put("title", entity.title)
            put("subject", entity.subject)
            put("grade", entity.grade)
            put("author", entity.author)
            put("created_at", entity.createdAt)
            put("sha256_checksum", entity.checksum)
        }.toString(2)

        val baos = ByteArrayOutputStream()
        ZipOutputStream(baos).use { zos ->
            writeEntry(zos, "manifest.json", manifest)
            writeEntry(zos, "student_content.json", entity.studentContentJson)
            writeEntry(zos, "socratic_bank.json", entity.socraticBankJson)
            writeEntry(zos, "teacher_studio.json", entity.teacherStudioJson)
        }
        return baos.toByteArray()
    }

    private fun writeEntry(zos: ZipOutputStream, name: String, content: String) {
        zos.putNextEntry(ZipEntry(name))
        zos.write(content.toByteArray(Charsets.UTF_8))
        zos.closeEntry()
    }
}
