package dev.pages.edutechmindset.data.share

import android.content.Context
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*
import dev.pages.edutechmindset.data.edupack.EduPackParser
import dev.pages.edutechmindset.data.edupack.EduPackWriter
import dev.pages.edutechmindset.data.local.EduPackEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.ByteArrayInputStream

class EduShareManager(
    context: Context,
    private val onPackReceived: (EduPackEntity) -> Unit
) {
    private val client = Nearby.getConnectionsClient(context)
    private val serviceId = "dev.pages.edutechmindset.EDUSHARE"

    private val _status = MutableStateFlow("جاهز للمشاركة المحلية بدون إنترنت")
    val status: StateFlow<String> = _status

    private val _discoveredEndpoints = MutableStateFlow<Map<String, String>>(emptyMap())
    val discoveredEndpoints: StateFlow<Map<String, String>> = _discoveredEndpoints

    private var packToSend: EduPackEntity? = null

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            val bytes = payload.asBytes() ?: return
            try {
                val entity = EduPackParser.parseFromZipStream(ByteArrayInputStream(bytes))
                onPackReceived(entity)
                _status.value = "✅ تم استلام الحزمة: ${entity.title}"
            } catch (e: Exception) {
                _status.value = "❌ تعذر فك الحزمة المستلمة: ${e.message}"
            }
        }

        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {
            if (update.status == PayloadTransferUpdate.Status.SUCCESS && packToSend != null) {
                _status.value = "✅ تم إرسال الحزمة بنجاح!"
            }
        }
    }

    private val connectionLifecycleCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            client.acceptConnection(endpointId, payloadCallback)
        }

        override fun onConnectionResult(endpointId: String, result: ConnectionResolution) {
            if (result.status.isSuccess) {
                _status.value = "🔗 متصل بالطرف الآخر"
                packToSend?.let { pack ->
                    val bytes = EduPackWriter.toZipBytes(pack)
                    client.sendPayload(endpointId, Payload.fromBytes(bytes))
                    _status.value = "📤 جارٍ بث الحزمة: ${pack.title}..."
                }
            } else {
                _status.value = "⚠️ فشل الاتصال"
            }
        }

        override fun onDisconnected(endpointId: String) {
            _status.value = "انتهى الاتصال"
        }
    }

    fun startBroadcasting(teacherName: String, pack: EduPackEntity) {
        stopAll()
        packToSend = pack
        val options = AdvertisingOptions.Builder().setStrategy(Strategy.P2P_STAR).build()
        client.startAdvertising(teacherName, serviceId, connectionLifecycleCallback, options)
            .addOnSuccessListener { _status.value = "📡 يتم الآن بث (${pack.title}) للأجهزة القريبة..." }
            .addOnFailureListener { _status.value = "❌ تعذر بدء البث: ${it.localizedMessage}" }
    }

    fun startDiscovering(studentName: String) {
        stopAll()
        packToSend = null
        val options = DiscoveryOptions.Builder().setStrategy(Strategy.P2P_STAR).build()
        client.startDiscovery(serviceId, object : EndpointDiscoveryCallback() {
            override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
                _discoveredEndpoints.value = _discoveredEndpoints.value + (endpointId to info.endpointName)
                _status.value = "🔎 تم العثور على مرسل قريب! اضغط للاتصال والاستلام"
            }

            override fun onEndpointLost(endpointId: String) {
                _discoveredEndpoints.value = _discoveredEndpoints.value - endpointId
            }
        }, options)
            .addOnSuccessListener { _status.value = "🔎 جارٍ البحث عن معلم أو زميل يبث حزمة..." }
            .addOnFailureListener { _status.value = "❌ تعذر البحث: ${it.localizedMessage}" }
    }

    fun connectToEndpoint(studentName: String, endpointId: String) {
        client.requestConnection(studentName, endpointId, connectionLifecycleCallback)
    }

    fun stopAll() {
        client.stopAdvertising()
        client.stopDiscovery()
        client.stopAllEndpoints()
        _discoveredEndpoints.value = emptyMap()
    }
}
