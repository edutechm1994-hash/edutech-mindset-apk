package dev.pages.edutechmindset.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [MindsetStateEntity::class, DailyCheckInEntity::class, EduPackEntity::class],
    version = 1,
    exportSchema = false
)
abstract class EduTechDatabase : RoomDatabase() {
    abstract fun dao(): EduTechDao

    companion object {
        @Volatile
        private var INSTANCE: EduTechDatabase? = null

        fun getInstance(context: Context): EduTechDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    EduTechDatabase::class.java,
                    "edutech_mindset_v5.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
