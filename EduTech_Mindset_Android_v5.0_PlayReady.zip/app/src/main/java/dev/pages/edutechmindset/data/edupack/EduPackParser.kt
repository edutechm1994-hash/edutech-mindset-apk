package dev.pages.edutechmindset.data.edupack

import dev.pages.edutechmindset.data.local.EduPackEntity
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream
import java.security.MessageDigest
import java.util.zip.ZipInputStream

object EduPackParser {

    fun parseFromZipStream(inputStream: InputStream): EduPackEntity {
        val entries = mutableMapOf<String, String>()
        ZipInputStream(inputStream).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                if (!entry.isDirectory) {
                    entries[entry.name] = zis.readBytes().toString(Charsets.UTF_8)
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
        val manifestStr = entries["manifest.json"] ?: error("ملف manifest.json مفقود")
        val studentStr = entries["student_content.json"] ?: error("ملف student_content.json مفقود")
        val socraticStr = entries["socratic_bank.json"] ?: """{"questions":[],"flashcards":[]}"""
        val teacherStr = entries["teacher_studio.json"] ?: """{"objectives":[],"timeline":[],"classroom_activity":""}"""

        val manifest = JSONObject(manifestStr)
        val expectedHash = manifest.optString("sha256_checksum", "")
        if (expectedHash.isNotBlank() && expectedHash != "built-in-verified") {
            val actual = sha256Hex(studentStr + socraticStr)
            require(actual == expectedHash) { "فشل التحقق من سلامة الحزمة (SHA-256 mismatch)" }
        }

        return EduPackEntity(
            packId = manifest.optString("pack_id", "pack-${System.currentTimeMillis()}"),
            title = manifest.optString("title", "حزمة تعليمية"),
            subject = manifest.optString("subject", "عام"),
            grade = manifest.optString("grade", "عام"),
            author = manifest.optString("author", "EduTech Mindset"),
            createdAt = manifest.optString("created_at", ""),
            checksum = expectedHash,
            studentContentJson = studentStr,
            socraticBankJson = socraticStr,
            teacherStudioJson = teacherStr
        )
    }

    fun toParsedModel(entity: EduPackEntity): ParsedEduPack {
        val sc = JSONObject(entity.studentContentJson)
        val sb = JSONObject(entity.socraticBankJson)
        val ts = JSONObject(entity.teacherStudioJson)

        val cards = mutableListOf<MicroCard>()
        val cardsArr = sc.optJSONArray("micro_cards") ?: JSONArray()
        for (i in 0 until cardsArr.length()) {
            val o = cardsArr.getJSONObject(i)
            cards.add(MicroCard(o.optString("title"), o.optString("body")))
        }

        val questions = mutableListOf<SocraticQuestion>()
        val qArr = sb.optJSONArray("questions") ?: JSONArray()
        for (i in 0 until qArr.length()) {
            val o = qArr.getJSONObject(i)
            questions.add(
                SocraticQuestion(
                    id = o.optString("id", "q$i"),
                    prompt = o.optString("prompt"),
                    options = jsonArrayToList(o.optJSONArray("options")),
                    correctIndex = o.optInt("correct_index", 0),
                    hints = jsonArrayToList(o.optJSONArray("hints"))
                )
            )
        }

        val flashcards = mutableListOf<Flashcard>()
        val fcArr = sb.optJSONArray("flashcards") ?: JSONArray()
        for (i in 0 until fcArr.length()) {
            val o = fcArr.getJSONObject(i)
            flashcards.add(Flashcard(o.optString("front"), o.optString("back")))
        }

        return ParsedEduPack(
            packId = entity.packId,
            title = entity.title,
            subject = entity.subject,
            grade = entity.grade,
            author = entity.author,
            summary = sc.optString("summary"),
            microCards = cards,
            questions = questions,
            flashcards = flashcards,
            objectives = jsonArrayToList(ts.optJSONArray("objectives")),
            timeline = jsonArrayToList(ts.optJSONArray("timeline")),
            classroomActivity = ts.optString("classroom_activity")
        )
    }

    fun builtInDemoEntity(): EduPackEntity = EduPackEntity(
        packId = "et-emergency-thinking-01",
        title = "صندوق الطوارئ التعليمي: التفكير العلمي وحل المشكلات",
        subject = "مهارات التفكير والعلوم",
        grade = "عام (الطالب والمعلم)",
        author = "EduTech Mindset — غزة",
        createdAt = "2026-11-24",
        checksum = "built-in-verified",
        studentContentJson = """
            {
              "summary": "التكنولوجيا مجرد أداة؛ العقلية التحليلية هي التي تحوّل أي تحدٍ إلى خطوات قابلة للحل.",
              "micro_cards": [
                {"title": "1. تفكيك المشكلة", "body": "قسّم المسألة المعقدة إلى 3 أجزاء: المعطيات، المطلوب، والعلاقة بينهما."},
                {"title": "2. قوة التجريب الموجه", "body": "جرّب مثالاً بأرقام صغيرة لتكتشف النمط أولاً ثم عمّمه."},
                {"title": "3. التعلّم من الخطأ", "body": "دوّن سبب الخطأ في سطر واحد لتتجاوزه نهائياً."}
              ]
            }
        """.trimIndent(),
        socraticBankJson = """
            {
              "questions": [
                {
                  "id": "q1",
                  "prompt": "واجهت مسألة طويلة وشعرت أنها صعبة، ما الخطوة الأولى الأذكى؟",
                  "options": [
                    "حفظ الإجابة النهائية من زميل",
                    "استخراج المعطيات وتحديد المطلوب وتجربة مثال بسيط",
                    "ترك السؤال تماماً"
                  ],
                  "correct_index": 1,
                  "hints": [
                    "تلميح 1: فكّر في خطوة تجعلك تفهم بنية المسألة بنفسك.",
                    "تلميح 2: تفكيك السؤال إلى معطيات ومطلوب يفتح لك 70% من الحل."
                  ]
                }
              ],
              "flashcards": [
                {"front": "ما القاعدة الذهبية لعقلية النمو؟", "back": "القدرات تنمو بالجهد الموجّه والتعلّم من الأخطاء."}
              ]
            }
        """.trimIndent(),
        teacherStudioJson = """
            {
              "objectives": ["تطبيق خطوات التفكيك الثلاثية على مسألة جديدة."],
              "timeline": ["0-5 د: تهيئة بعقلية النمو", "5-25 د: تطبيق سقراطي في مجموعات"],
              "classroom_activity": "وزّع مسألة واحدة بدون أرقام واطلب كتابة خطة الحل بالكلمات."
            }
        """.trimIndent()
    )

    private fun jsonArrayToList(arr: JSONArray?): List<String> {
        if (arr == null) return emptyList()
        return (0 until arr.length()).map { arr.optString(it) }
    }

    private fun sha256Hex(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
