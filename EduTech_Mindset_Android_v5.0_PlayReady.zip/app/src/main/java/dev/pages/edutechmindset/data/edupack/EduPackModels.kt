package dev.pages.edutechmindset.data.edupack

data class MicroCard(val title: String, val body: String)

data class SocraticQuestion(
    val id: String,
    val prompt: String,
    val options: List<String>,
    val correctIndex: Int,
    val hints: List<String>
)

data class Flashcard(val front: String, val back: String)

data class ParsedEduPack(
    val packId: String,
    val title: String,
    val subject: String,
    val grade: String,
    val author: String,
    val summary: String,
    val microCards: List<MicroCard>,
    val questions: List<SocraticQuestion>,
    val flashcards: List<Flashcard>,
    val objectives: List<String>,
    val timeline: List<String>,
    val classroomActivity: String
)
